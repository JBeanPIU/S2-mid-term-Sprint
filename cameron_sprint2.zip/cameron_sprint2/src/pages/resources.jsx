import React from "react";
import './ab-re.css';

export const Resources = () => {
    return <div className="body">
        <div>
            <h2>Hi! As shown in the 'About' section, I'm Cameron Beanland.</h2>
            <h3>This tiny section is simply the resources I've used to construct this website, <br />most notably the images provided, 
                and use of phosphor-react with the shopping cart icon!</h3>
            <h2>Sources Used:</h2>
            <p><i>-<a href="https://www.youtube.com/" target="_blank" rel="noopener noreferrer">YouTube</a>, many sources there to help give an idea of how to write out 
                  some functions and overall help with React page design-</i></p>
            <p><i>-For similar usage, <a href="https://www.w3schools.com/" target="_blank" rel="noopener noreferrer">W3Schools</a> online web tuts is a great way to search
                  for relevant information on JS, and can easily help me find the tools or commands needed. *i have awful memory-</i></p>  
            <p><i>-The adorable <a href="https://www.etsy.com/market/crocodile_sitting?msockid=3ca2c89c48e8629c3ee1dc50493e63f1" target="_blank" rel="noopener noreferrer">Chubby Dog</a>, can be found 
                  on etsy for purchase-</i></p>     
            <p><i>-All other photos have been taken from <a href="https://www.pexels.com/search/shoes/" target="_blank" rel="noopener noreferrer">Pexels</a>, a free-use stock image
                  website-</i></p>
            <h3>Besides those, there may be a few other sites, videos, or just general information that I may have left out. Although <br />overall, 
                a lot more stressful than I had imagined! Now to take a nice break before third semester 💀</h3>   
            <h1>Goodbye S2!</h1>   
        </div>
    </div>
}