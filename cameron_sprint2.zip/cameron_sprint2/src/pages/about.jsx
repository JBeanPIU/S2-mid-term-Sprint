import React from "react";
import './ab-re.css'

export const About = () => {
    return <div className="body">
        <h1>
            About <span className="blueText">Us!</span>
        </h1>
        <p><i>-We (me) are a hypothetical ecommerce site, built using React! JRIP is a company dedicated to <b>your</b> needs. Our company has sought nothing but <br />customer
              satisfaction since 2001, so join us today and support our little 2.8 billions worth of wealth!-</i></p>
        <p><i>-J<span className="purpText">RIP</span> prides itself on <s>ripping people off</s> giving the highest quality to our beloved spenders! With our unbeatable <br />
              selection of goods & wares, what else are you going to spend your money on? Come on down to our <br />
              many locations across the globe: 2.</i></p>
        <br />
        <p><i>*disclosure, this is not a real website. Any and all scams related to money are purely ficticious, and we will (most likely) not try to actually steal your cash.</i></p>
        <br />
        <p><i>My name is Cameron Beanland, if you managed to check the resources page <b>before</b> you'll already know that. Or if you've noticed my GitHub profile. <br />
              Regardless, at the time of making this assignment I am a 23 year old enrolled at Keyin College. My passion is ultimately making video games, but I also do <br />
              love creating websites and seeing how they work on the inside. JavaScript continues to smooth my brain out, just when I think I'm getting the hang of it. <br />
              Despite that, this is my submission for the Final Sprint of Semester 2, taught to us by Noman Atique.</i></p>
        <br />
        <p><i>Although this was pretty tough to cram out, I still feel confident in my abilities going forward and hope to keep improving! If I can't code websites then <br />
              there is zero chance I'll create a game either LOL. So long as I pass this we're onto the next round, so thanks for reading if you did!</i></p>
              <h3>Cameron Beanland</h3>
              <h3>August 12th, 2024</h3>
              <h3>🔥🔥🔥🔥🔥🔥🔥</h3>
    </div>
}