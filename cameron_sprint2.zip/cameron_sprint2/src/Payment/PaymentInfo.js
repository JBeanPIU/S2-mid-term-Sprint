import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import './paymentInfo.css';

export const PaymentInfo = () => {
    const [cardNumber, setCardNumber] = useState("");
    const [expiryDate, setExpiryDate] = useState("");
    const [cvv, setCvv] = useState("");
    const [address, setAddress] = useState("");
    const [city, setCity] = useState("");
    const [postalCode, setPostalCode] = useState("");

    const navigate = useNavigate();

    const handlePaymentSubmit = (e) => {
        e.preventDefault();
        if (validateForm()) {
            navigate("/confirm-payment");
        } else {
            alert("Please fill out the form correctly.");
        }
    };

    const validateForm = () => {
        const cardRegex = /^\d{16}$/;
        const cvvRegex = /^\d{3}$/;
        const postalCodeRegex = /^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$/;

        return (
            cardRegex.test(cardNumber) &&
            expiryDate !== "" &&
            cvvRegex.test(cvv) &&
            address !== "" &&
            city !== "" &&
            postalCodeRegex.test(postalCode)
        );
    };

    return (
        <div className="payment-form">
            <h2>Enter Your Banking Information</h2>
            <form onSubmit={handlePaymentSubmit}>
                <div>
                    <label>Card Number:</label>
                    <input 
                        type="text" 
                        value={cardNumber} 
                        onChange={(e) => setCardNumber(e.target.value)} 
                        placeholder="16-digit card number"
                        maxLength={16}
                    />
                </div>
                <div>
                    <label>Expiry Date:</label>
                    <input 
                        type="month" 
                        value={expiryDate} 
                        onChange={(e) => setExpiryDate(e.target.value)} 
                    />
                </div>
                <div>
                    <label>CVV:</label>
                    <input 
                        type="text" 
                        value={cvv} 
                        onChange={(e) => setCvv(e.target.value)} 
                        placeholder="3-digit CVV"
                        maxLength={3}
                    />
                </div>
                <h2>Shipping Address</h2>
                <div>
                    <label>Address:</label>
                    <input 
                        type="text" 
                        value={address} 
                        onChange={(e) => setAddress(e.target.value)} 
                    />
                </div>
                <div>
                    <label>City:</label>
                    <input 
                        type="text" 
                        value={city} 
                        onChange={(e) => setCity(e.target.value)} 
                    />
                </div>
                <div>
                    <label>Postal Code:</label>
                    <input 
                        type="text" 
                        value={postalCode} 
                        onChange={(e) => setPostalCode(e.target.value)} 
                        placeholder="A1A 1A1"
                    />
                </div>
                <button type="submit">Proceed to Confirmation</button>
            </form>
        </div>
    );
};