import React from "react";
import { useNavigate } from "react-router-dom";
import './thankYou.css';

export const ThankYou = () => {
    const navigate = useNavigate();

    return (
        <div className="thank-you">
            <h2>Thank You for Your Purchase!</h2>
            <button onClick={() => navigate("/")}>Continue Shopping</button>
        </div>
    );
};