import React from "react";
import { useNavigate } from "react-router-dom";
import './confirmPayment.css';

export const ConfirmPayment = () => {
    const navigate = useNavigate();

    const handleConfirmation = (confirm) => {
        if (confirm) {
            navigate("/thank-you");
        } else {
            navigate("/cart");
        }
    };

    return (
        <div className="confirmation">
            <h2>Confirm Your Payment</h2>
            <p>Do you wish to proceed with the payment?</p>
            <button onClick={() => handleConfirmation(true)}>Yes</button>
            <button onClick={() => handleConfirmation(false)}>No</button>
        </div>
    );
};