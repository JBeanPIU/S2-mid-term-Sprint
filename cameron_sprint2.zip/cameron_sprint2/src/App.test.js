/*By: Cameron Beanland */
/*Date: August 12th, 2024 */
/*Purpose: Creation of a fully functioning e-commerce website, with the use of React. This assignment is to be submitted as my Final Sprint
           for semester 2 of Keyin College!  */
    
import { render, screen } from '@testing-library/react';
import App from './App';

test('renders learn react link', () => {
  render(<App />);
  const linkElement = screen.getByText(/learn react/i);
  expect(linkElement).toBeInTheDocument();
});
