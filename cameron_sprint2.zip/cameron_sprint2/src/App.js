/*By: Cameron Beanland */
/*Date: August 12th, 2024 */
/*Purpose: Creation of a fully functioning e-commerce website, with the use of React. This assignment is to be submitted as my Final Sprint
           for semester 2 of Keyin College!  */

import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { NavBar } from './comps/navbar';
import { Shop } from './pages/shop';
import { Cart } from './pages/cart';
import { About } from './pages/about';
import { Resources } from './pages/resources';
import { ShopContextProvider } from './context/shop-context';

function App() {
  return (
    <div className="App">
      <ShopContextProvider>
        <Router>
          <NavBar />
          <Routes>
            <Route path="/" element={<Shop />} />
            <Route path="/cart" element={<Cart />}/>
            <Route path="/about" element={<About />}/>
            <Route path="/resources" element={<Resources />}/>
          </Routes>
        </Router>
      </ShopContextProvider>
    </div>
  );
}

export default App;
