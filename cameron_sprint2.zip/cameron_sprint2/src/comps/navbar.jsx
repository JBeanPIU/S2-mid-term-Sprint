import React from "react";
import './navbar.css'; 
import { Link } from 'react-router-dom';
import { ShoppingCart } from 'phosphor-react';
import logo from '../assets/jrip_logo.png';

export const NavBar = () => {
    return (
        <div className="navBar">
            <div className="logo">
                <img src={logo} alt="JRIP LOGO" />
            </div>
            <div className="links">
                <Link to="/"> Shop </Link>
                <Link to="/about"> About </Link>
                <Link to="/resources"> Resources </Link>
                <Link to="/cart"><ShoppingCart size={52} /></Link>
            </div>
        </div>
    );
};