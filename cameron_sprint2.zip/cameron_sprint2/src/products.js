import product1 from './assets/1.jpg'
import product2 from './assets/2.jpg'
import product3 from './assets/3.jpg'
import product4 from './assets/4.jpg'
import product5 from './assets/5.jpg'
import product6 from './assets/6.jpg'

export const PRODUCTS = [
    {
        id: 1,
        productName: "iPhone",
        price: 729.0,
        productImage: product1,
    },
    {
        id: 2,
        productName: "Camera",
        price: 499.0,
        productImage: product2,
    },
    {
        id: 3,
        productName: "Rolex",
        price: 649.0,
        productImage: product3,
    },
    {
        id: 4,
        productName: "Half Finished Sprite",
        price: 1.0,
        productImage: product4,
    },
    {
        id: 5,
        productName: "Bulb Design White Tee",
        price: 15.0,
        productImage: product5,
    },
    {
        id: 6,
        productName: "Dog",
        price: 70.0,
        productImage: product6,
    },
] 

